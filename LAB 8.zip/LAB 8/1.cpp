#include <iostream>
using namespace std;

const int Queue_Capacity = 5;

class Queue {
public:
    Queue() {
        front = rear = -1;
    }
    
    bool isEmpty() {
        return front == rear;
    }
    
    bool isFull() {
        return rear == Queue_Capacity - 1;
    }
    
    void enqueue(int value) {
        if (isFull()) {
            cout << "Queue is Full!" << endl;
        } else {
            myArray[++rear] = value;
        }
    }
    
    int dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty" << endl;
            return -1;
        } else {
            return myArray[++front];
        }
    }
    
    void display() {
        if (isEmpty()) {
            cout << "Queue is empty" << endl;
        } else {
            cout << "Queue elements: ";
            for (int i = front + 1; i <= rear; i++) {
                cout << myArray[i] << " ";
            }
            cout << endl;
        }
    }

private:
    int myArray[Queue_Capacity];
    int front, rear;
};

int main() {
    Queue q;
    q.enqueue(5);
    q.enqueue(10);
    q.enqueue(15);
    q.enqueue(20);
    q.enqueue(25);
    
    cout << "Queue: " << endl;
    q.display();  

    q.dequeue();
    cout << "After one dequeue:" << endl;
    q.display(); 

    return 0;
}

